GraphQL as backend
It will not work without a server, which you can find 