import TextInputForm from './TextInputForm';

export default TextInputForm;
