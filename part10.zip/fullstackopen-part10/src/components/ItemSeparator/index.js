import ItemSeparator from './SeparatingItem';

export default ItemSeparator;
