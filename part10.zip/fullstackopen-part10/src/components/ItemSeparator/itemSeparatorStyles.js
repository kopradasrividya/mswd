import { StyleSheet } from 'react-native';

const itemSeparatorStyles = StyleSheet.create({
  separator: {
    height: 6,
  },
});
export default itemSeparatorStyles;
