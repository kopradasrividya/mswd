import RowView from './RowView';

export default RowView;
