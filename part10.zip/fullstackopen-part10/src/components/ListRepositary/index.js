import RepositoryList from './RepositoryList';

export default RepositoryList;
