const initialValues = {
  ownerName: '',
  repositoryName: '',
  rating: undefined,
  text: undefined,
};

export default initialValues;
