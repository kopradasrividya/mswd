const initialValues = {
  username: '',
  password: '',
};

export default initialValues;
