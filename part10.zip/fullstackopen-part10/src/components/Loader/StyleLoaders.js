import { StyleSheet } from 'react-native';
const StyleLoaders = StyleSheet.create({
  loader: {
    padding: 5,
  },
});
export default StyleLoaders;
