import Loader from './LoadMaker';
export default Loader;
