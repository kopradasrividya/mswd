import MyReviews from './MyReview';

export default MyReviews;
