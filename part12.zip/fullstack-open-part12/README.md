# Full Stack 2021 - Part 12 | Containers
Front and Backend full stack of TODO. 
Containers Included.
