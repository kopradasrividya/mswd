# Express application

Install dependencies with `npm install`
Run with `npm start`
Or in development mode with `npm run dev`
# MongoDB

The application has /todos crud which requires a MongoDB. Pass connection url with env `MONGO_URL`